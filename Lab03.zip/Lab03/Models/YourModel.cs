﻿namespace ReadDB.Models
{
    public class YourModel
    {
        public int id { get; set; }
        public string product { get; set; }
        public decimal price { get; set; }
        public DateTime date { get; set; }
    }
}
