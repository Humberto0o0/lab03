using Microsoft.AspNetCore.Mvc;
using ReadDB.Data;
using ReadDB.Models;
using System.Collections.Generic;

namespace ReadDB.Controllers
{
    public class HomeController : Controller
    {
        private readonly DataAccess _dataAccess;

        public HomeController(DataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public IActionResult Index()
        {
            List<YourModel> model = _dataAccess.GetData();
            return View(model);
        }
    }
}
