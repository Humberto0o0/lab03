﻿using Microsoft.EntityFrameworkCore;
using Lab03.Models;

namespace Lab03.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Price> Prices { get; set; }
        public DbSet<YourModel> YourModels { get; set; }
    }

    public class Price
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public decimal PriceValue { get; set; }
        public DateTime Date { get; set; }
    }
}
