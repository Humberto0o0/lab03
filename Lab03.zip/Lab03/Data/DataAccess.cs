﻿using Microsoft.AspNetCore.Mvc;

using ReadDB.Models;

namespace ReadDB.Controllers
{
    public class HomeController : Controller
    {
        private readonly DataAccess _dataAccess;

        public HomeController(DataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public IActionResult Index()
        {
            List<YourModel> data = _dataAccess.GetData();
            return View(data);
        }
    }
}
